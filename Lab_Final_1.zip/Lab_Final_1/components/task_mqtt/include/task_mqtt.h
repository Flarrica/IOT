#ifndef TASK_MQTT_H
#define TASK_MQTT_H

void iniciar_task_mqtt(void);
void mqtt_task_agregar_mensaje(const char *mensaje);

#endif // TASK_MQTT_H