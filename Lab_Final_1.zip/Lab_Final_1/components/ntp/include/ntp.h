#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void ntp_sync_inicializar(void);

#ifdef __cplusplus
}
#endif